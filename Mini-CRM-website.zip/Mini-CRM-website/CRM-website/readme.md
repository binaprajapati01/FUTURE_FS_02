# 🧩 Mini CRM

A simple Customer Relationship Management (CRM) system to manage client leads.

## 🚀 Features
- Add new leads with name, email, and notes
- View all leads in a list
- Update lead status (New, Contacted, Closed)
- Backend API with Node.js + Express

## 📁 Folder Structure
mini-crm/
├── public/ (frontend)
├── server/ (backend)
├── package.json
├── README.md

## 🛠 Tech Stack
- Frontend: HTML, CSS, JavaScript
- Backend: Node.js, Express
- Database: MongoDB (optional, currently using in-memory storage)

## 📬 Usage
1. Install dependencies:
   ```bash
   npm install express body-parser cors
